let errores = [];
errores.push('error1');
errores.push('error2');
errores.push('error3');
errores.push('error4');
errores.push('errornotaexamen');


function validar(){
    let entradas = [];
    entradas.push(parseFloat(document.getElementById("nota1").value));
    entradas.push(parseFloat(document.getElementById("nota2").value));
    entradas.push(parseFloat(document.getElementById("nota3").value));
    entradas.push(parseFloat(document.getElementById("nota4").value));
    entradas.push(parseFloat(document.getElementById("notaexamen").value));
    console.table(entradas);

    let errorMsg = 'La nota no es válida';


    for(i in entradas){
        if(entradas[i] < 1 || entradas[i]>7 || entradas[i] == "" || isNaN(entradas[i])){
            errores[i] =document.getElementById([errores[i]]).innerHTML = errorMsg;
            return; 
        }
    }
    let promedio = 0;
    for(let i = 0; i < 4; i++){
        promedio += entradas[i];
    }
    promedio = promedio/4;
    let promedio_final = (promedio*0.6)+(entradas[4]*0.4);
    document.getElementById("promedio").innerHTML = "Promedio notas : " +promedio.toFixed(2);
  
    if((promedio_final < 4.0) || (promedio <= 3.9)){
        document.getElementById("resultado").innerHTML = "<h4 class='text-danger'>Reprobaste</h4>";
    }else{
        document.getElementById("resultado").innerHTML = "<h4 class='text-success'>Aprobado </h4>";
    }
    

}   

function limpiar(){
    errores[i] =document.getElementById("error1").innerHTML = "";
    errores[i] =document.getElementById("error2").innerHTML = "";
    errores[i] =document.getElementById("error3").innerHTML = "";
    errores[i] =document.getElementById("error4").innerHTML = "";
    errores[i] =document.getElementById("errornotaexamen").innerHTML = "";
}
